const { app, BrowserWindow, ipcMain, dialog, shell, nativeImage, clipboard, Menu } = require('electron');
const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs');

let win;
let cropWin=null;
let fullscreen = false;
let pendingOpenPath=null;
function allowElevatedDrop(target){ if(process.platform!=='win32') return; try{ const raw=target.getNativeWindowHandle(); const hwnd=raw.length>=8?raw.readBigUInt64LE(0):BigInt(raw.readUInt32LE(0)); const ps=`Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class DropFilter { [DllImport("user32.dll",SetLastError=true)] public static extern bool ChangeWindowMessageFilterEx(IntPtr hWnd,uint msg,uint action,IntPtr changeFilterStruct); }'; $h=[IntPtr]::new([long]${hwnd}); foreach($m in @(0x233,0x4A,0x49)){ [void][DropFilter]::ChangeWindowMessageFilterEx($h,$m,1,[IntPtr]::Zero) }`; execFile('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',ps],{windowsHide:true}); }catch{} }
function firstImageArgument(argv){ const exts=new Set(['jpg','jpeg','png','gif','webp','bmp','tif','tiff','ico','avif']); return (argv||[]).slice(1).find(v=>typeof v==='string' && fs.existsSync(v) && fs.statSync(v).isFile() && exts.has(path.extname(v).slice(1).toLowerCase())) || null; }
pendingOpenPath=firstImageArgument(process.argv);

function createWindow() {
  win = new BrowserWindow({
    width: 1180,
    height: 760,
    minWidth: 720,
    minHeight: 480,
    backgroundColor: '#151515',
    frame: false,
    show: true,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => { win.show(); allowElevatedDrop(win); if(pendingOpenPath) { win.webContents.send('open-file-path', pendingOpenPath); pendingOpenPath=null; } });
    win.setMenu(null);
    win.on('enter-full-screen', () => { fullscreen = true; win.webContents.send('fullscreen-changed', true); });
  win.on('leave-full-screen', () => { fullscreen = false; win.webContents.send('fullscreen-changed', false); });
}

const hasLock=app.requestSingleInstanceLock();
if(!hasLock){ app.quit(); } else {
  app.on('second-instance', (_, argv) => { const p=firstImageArgument(argv); if(p&&win){ if(win.isMinimized())win.restore(); win.focus(); win.webContents.send('open-file-path',p); } });
  app.whenReady().then(createWindow);
}
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });

const IMAGE_EXTENSIONS = new Set(['jpg','jpeg','png','gif','webp','bmp','tif','tiff','ico','avif']);
function isSupportedImage(filePath){ return IMAGE_EXTENSIONS.has(path.extname(filePath).slice(1).toLowerCase()); }
function naturalSort(a,b){ return a.localeCompare(b, undefined, {numeric:true, sensitivity:'base'}); }
function expandImagePaths(filePaths){
  const out=[]; const seen=new Set();
  for(const input of Array.isArray(filePaths)?filePaths:[]){
    if(!input || !fs.existsSync(input)) continue;
    const stat=fs.statSync(input);
    const dir=stat.isDirectory()?input:path.dirname(input);
    const entries=fs.readdirSync(dir,{withFileTypes:true}).filter(e=>e.isFile() && isSupportedImage(e.name)).map(e=>path.join(dir,e.name)).sort(naturalSort);
    for(const p of entries) if(!seen.has(p)){seen.add(p);out.push(p)}
  }
  return out;
}
ipcMain.handle('open-crop-window', (_, payload) => { if(cropWin&&!cropWin.isDestroyed()){cropWin.focus();return true} cropWin=new BrowserWindow({width:980,height:720,minWidth:640,minHeight:480,parent:win,modal:false,show:false,autoHideMenuBar:true,backgroundColor:'#111820',icon:path.join(__dirname,'assets','icon.ico'),webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false}}); cropWin.setMenu(null); cropWin.loadFile(path.join(__dirname,'renderer','crop.html')); cropWin.once('ready-to-show',()=>{cropWin.show();cropWin.webContents.send('crop-image',payload||{})}); cropWin.on('closed',()=>{cropWin=null}); return true; });
ipcMain.handle('close-crop-window',()=>{if(cropWin&&!cropWin.isDestroyed())cropWin.close();return true});
ipcMain.handle('open-images', async () => {
  const result = await dialog.showOpenDialog(win, { properties: ['openFile', 'multiSelections'], filters: [{ name: 'الصور', extensions: ['jpg','jpeg','png','gif','webp','bmp','tif','tiff','ico','avif'] }] });
  if(result.canceled||!result.filePaths.length) return {selected:null,paths:[]};
  const selected=result.filePaths[0];
  return {selected,paths:expandImagePaths(result.filePaths)};
});
ipcMain.handle('expand-images', (_, filePaths) => expandImagePaths(filePaths));
ipcMain.handle('window-action', (_, action) => {
  if (action === 'minimize') win.minimize();
  if (action === 'maximize') win.isMaximized() ? win.unmaximize() : win.maximize();
  if (action === 'close') win.close();
});
ipcMain.handle('set-fullscreen', (_, value) => { win.setFullScreen(Boolean(value)); fullscreen = Boolean(value); return fullscreen; });
ipcMain.handle('get-fullscreen', () => fullscreen);
function writeFileClipboard(filePath, cut=false){
  if(process.platform!=='win32' || !filePath || !fs.existsSync(filePath)) return false;
  return new Promise(resolve=>{
    const safe=String(filePath).replace(/'/g,"''");
    const effect=cut?2:1;
    const ps=`Add-Type -AssemblyName System.Windows.Forms; $files=New-Object System.Collections.Specialized.StringCollection; [void]$files.Add('${safe}'); $data=New-Object System.Windows.Forms.DataObject; $data.SetFileDropList($files); $data.SetData('Preferred DropEffect',$false,[byte[]](${effect},0,0,0)); [System.Windows.Forms.Clipboard]::SetDataObject($data,$true)`;
    execFile('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',ps],{windowsHide:true},err=>resolve(!err));
  });
}
ipcMain.handle('copy-image', (_, filePath) => writeFileClipboard(filePath,false));
ipcMain.handle('cut-image', (_, filePath) => writeFileClipboard(filePath,true));
ipcMain.handle('rename-image', async (_, filePath, newName) => { if(!filePath || !fs.existsSync(filePath) || typeof newName!=='string') return false; const trimmed=newName.trim(); if(!trimmed || /[<>:"/\\|?*]/.test(trimmed)) return false; try { const ext=path.extname(filePath); const finalName=path.extname(trimmed)?trimmed:trimmed+ext; const target=path.join(path.dirname(filePath),finalName); if(path.resolve(target)!==path.resolve(filePath) && fs.existsSync(target)) return false; fs.renameSync(filePath,target); return target; } catch { return false; } });
ipcMain.handle('delete-image', async (_, filePath) => { if(!filePath || !fs.existsSync(filePath)) return false; try { await shell.trashItem(filePath); return true; } catch { return false; } });
ipcMain.handle('paste-image', async () => { try { const files=await new Promise(resolve=>{const ps=`Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Clipboard]::GetFileDropList() | ForEach-Object { $_ }`; execFile('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',ps],{windowsHide:true,encoding:'utf8'},(_,stdout)=>resolve(String(stdout||'').split(/\r?\n/).map(x=>x.trim()).filter(x=>x&&fs.existsSync(x)&&fs.statSync(x).isFile())))}); const imageFile=files.find(isSupportedImage); if(imageFile)return imageFile; const image=clipboard.readImage(); if(image.isEmpty())return null; const target=path.join(app.getPath('userData'),'pasted-'+Date.now()+'.png'); fs.writeFileSync(target,image.toPNG()); return target; } catch { return null; } });

ipcMain.handle('rename-text-context-menu', event => { const target=BrowserWindow.fromWebContents(event.sender); if(!target)return false; Menu.buildFromTemplate([{label:'نسخ',role:'copy'},{label:'لصق',role:'paste'},{label:'قص',role:'cut'},{label:'حذف',role:'delete'}]).popup({window:target}); return true; });
ipcMain.handle('show-in-folder', (_, filePath) => { if (filePath) shell.showItemInFolder(filePath); });
ipcMain.handle('save-cropped', async (_, dataUrl) => { try { if(typeof dataUrl!=='string'||!dataUrl.startsWith('data:image/png;base64,')) return false; const result=await dialog.showSaveDialog(win,{defaultPath:'صورة مقصوصة.png',filters:[{name:'PNG',extensions:['png']}]}); if(result.canceled||!result.filePath)return false; const base64=dataUrl.slice('data:image/png;base64,'.length); const buffer=Buffer.from(base64,'base64'); if(!buffer.length)return false; fs.writeFileSync(result.filePath,buffer,{flag:'w'}); return fs.existsSync(result.filePath)?result.filePath:false; } catch(error) { return false; } });
ipcMain.handle('set-wallpaper-data', (_, dataUrl) => new Promise(resolve => { if(process.platform!=='win32'||typeof dataUrl!=='string'||!dataUrl.startsWith('data:image/')){resolve(false);return} const target=path.join(app.getPath('userData'),'wallpaper.png'); try{fs.writeFileSync(target,Buffer.from(dataUrl.split(',')[1],'base64'))}catch(e){resolve(false);return} ipcMain.emit('set-wallpaper-internal',target,resolve); }));
ipcMain.on('set-wallpaper-internal',(target,resolve)=>{ const safe=target.replace(/'/g,"''"); const ps=`Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public class WallpaperData { [DllImport(\"user32.dll\",CharSet=CharSet.Unicode)] public static extern bool SystemParametersInfo(int action,int param,string file,int flags); }'; if([WallpaperData]::SystemParametersInfo(20,0,'${safe}',3)){ exit 0 } else { exit 1 }`; execFile('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',ps],err=>resolve(!err)); });
ipcMain.handle('set-wallpaper', (_, filePath) => new Promise(resolve => { if(process.platform!=='win32' || !filePath || !fs.existsSync(filePath)){resolve(false);return} const ext=path.extname(filePath)||'.png'; const target=path.join(app.getPath('userData'),'wallpaper'+ext); try{fs.copyFileSync(filePath,target)}catch(e){resolve(false);return} const safe=target.replace(/'/g,"''"); const ps=`Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public class Wallpaper { [DllImport(\"user32.dll\",CharSet=CharSet.Unicode)] public static extern bool SystemParametersInfo(int action,int param,string file,int flags); }'; if([Wallpaper]::SystemParametersInfo(20,0,'${safe}',3)){ exit 0 } else { exit 1 }`; execFile('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',ps],err=>resolve(!err)); }));
ipcMain.handle('image-data-url', (_, filePath) => { if(!filePath || !fs.existsSync(filePath)) return null; const mime={jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',gif:'image/gif',webp:'image/webp',bmp:'image/bmp',tif:'image/tiff',tiff:'image/tiff',ico:'image/x-icon',avif:'image/avif'}[path.extname(filePath).slice(1).toLowerCase()]||'application/octet-stream'; return `data:${mime};base64,${fs.readFileSync(filePath).toString('base64')}`; });
ipcMain.handle('image-info', (_, filePath) => {
  if (!filePath || !fs.existsSync(filePath)) return null;
  const stat = fs.statSync(filePath);
  const image = nativeImage.createFromPath(filePath);
  const size = image.getSize();
  return { name: path.basename(filePath), path: filePath, width: size.width, height: size.height, bytes: stat.size, modified: stat.mtime.toLocaleString('ar-EG') };
});
